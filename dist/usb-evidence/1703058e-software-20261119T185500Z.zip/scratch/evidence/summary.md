# Pulsr USB HIL summary

- Verdict: **BLOCKED**
- Gate green: no
- Generated: 2026-11-19T17:44:34.334Z
- Build: 1703058e
- Results: 4 (pass 0, fail 0, blocked 4, error 0)
- Reason: one or more gates blocked

## Results

| File | Kind | Status | Reason | Cases |
| :--- | :--- | :--- | :--- | :--- |
| matrix.json | matrix | blocked | no_device | 18 |
| smoke.json | smoke | blocked | no_device | 3 |
| soak.json | soak | blocked | no_device | 5 |
| unplug.json | unplug_replug | blocked | no_device | 4 |

## Blocked (hardware gates not met)

| File | Kind | Reason | Detail |
| :--- | :--- | :--- | :--- |
| matrix.json | matrix | no_device | adb reported zero attached devices |
| smoke.json | smoke | no_device | adb reported zero attached devices |
| soak.json | soak | no_device | adb reported zero attached devices |
| unplug.json | unplug_replug | no_device | adb reported zero attached devices |
| unplug.json | unplug_replug | no_relay | no --relay-cmd supplied; no cable was pulled and zero cycles are claimed |

_Blocked is not a pass: no device evidence was produced for these gates._

## Case detail (non-pass)

- `matrix` / `uac2-async-44100`: blocked (no_device)
- `matrix` / `uac2-async-48000`: blocked (no_device)
- `matrix` / `uac2-async-96000`: blocked (no_device)
- `matrix` / `uac2-async-192000`: blocked (no_device)
- `matrix` / `uac2-async-384000`: blocked (no_device)
- `matrix` / `uac1-fs-44100`: blocked (no_device)
- `matrix` / `uac1-fs-48000`: blocked (no_device)
- `matrix` / `uac1-hs-96000`: blocked (no_device)
- `matrix` / `uac1-hs-192000`: blocked (no_device)
- `matrix` / `uac2-24in32`: blocked (no_device)
- `matrix` / `uac2-hardware-volume`: blocked (no_device)
- `matrix` / `uac1-feedbackless-dongle`: blocked (no_device)
- `matrix` / `uac2-705600`: blocked (no_device)
- `matrix` / `uac2-768000`: blocked (no_device)
- `matrix` / `uac2-dop-dsd128`: blocked (no_device)
- `matrix` / `uac2-6ch`: blocked (no_device)
- `matrix` / `uac2-8ch`: blocked (no_device)
- `matrix` / `uac2-32bit-384000`: blocked (no_device)
- `smoke` / `start_latency`: blocked (no_device)
- `smoke` / `stop_latency`: blocked (no_device)
- `smoke` / `underrun_stability`: blocked (no_device)
- `soak` / `samples_collected`: blocked (no_device)
- `soak` / `counter_monotonicity`: blocked (no_device)
- `soak` / `duration_drift`: blocked (no_device)
- `soak` / `underrun_budget`: blocked (no_device)
- `soak` / `overrun_budget`: blocked (no_device)
- `unplug_replug` / `cycles_completed`: blocked (no_device)
- `unplug_replug` / `recovery_budget`: blocked (no_device)
- `unplug_replug` / `pid_stability`: blocked (no_device)
- `unplug_replug` / `drain_pending_cleared`: blocked (no_device)
